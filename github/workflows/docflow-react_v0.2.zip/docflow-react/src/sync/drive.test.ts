import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DRIVE_ROOT_NAME, DriveAuthError, DriveClient, type LayoutStore } from './drive.ts';
import { FakeDrive } from './testing/fakeDrive.ts';
import { normalizeAppData } from '../core/normalize.ts';
import { docsForScope, planFiles } from '../core/exportPlan.ts';

const mkData = () => normalizeAppData({
  categories: [
    { id: 'c1', name: 'כספים', subs: [{ id: 's', name: 'רכב' }], folders: [{ id: 'a', name: 'חשבוניות', subId: 's' }, { id: 'b', name: '2026', parentId: 'a' }] },
    { id: 'c2', name: 'אחר' }
  ],
  documents: [
    { id: 'd1', title: 'שורש', categoryId: 'c1', fileKey: 'k1', fileName: 'root.txt' },
    { id: 'd2', title: 'עמוק', categoryId: 'c1', folderId: 'b', fileKey: 'k2', fileName: 'a.png' },
    { id: 'd3', title: 'ב', categoryId: 'c1', folderId: 'a', fileKey: 'k3', fileName: 'b.pdf',
      versions: [{ version: 'v1.0', fileKey: 'old3', fileName: 'b.pdf' }, { version: 'v2.0', fileKey: 'k3', fileName: 'b.pdf' }] },
    { id: 'd4', title: 'נמחק', categoryId: 'c2', fileKey: 'k4', fileName: 'z.docx', isDeleted: true }
  ]
});
const live = (data: ReturnType<typeof mkData>) => docsForScope(data, { kind: 'all' })!.docs;
const memLayout = (): LayoutStore & { v: Record<string, string> } => { const s = { v: {} as Record<string, string>, get() { return s.v; }, set(x: Record<string, string>) { s.v = x; } }; return s; };
const setup = () => { const drive = new FakeDrive(); const client = new DriveClient({ getToken: () => drive.token, fetchImpl: drive.fetch }); return { drive, client }; };

test('ensurePath יוצר תיקיות פעם אחת בלבד ושומר על המבנה', async () => {
  const { drive, client } = setup();
  const id1 = await client.ensurePath(['כספים', 'רכב']);
  const id2 = await client.ensurePath(['כספים', 'רכב']);
  assert.equal(id1, id2);
  assert.equal(drive.nodes.filter((n) => n.name === 'כספים').length, 1);
  const root = drive.byName(DRIVE_ROOT_NAME)!;
  assert.equal(root.props.docflowExportRoot, '1');
  assert.equal(drive.byName('כספים')!.parents[0], root.id);
  assert.equal(drive.byName('רכב')!.parents[0], drive.byName('כספים')!.id);
  // לקוח חדש (למשל אחרי רענון) מוצא את אותן תיקיות ולא יוצר כפילות
  const again = new DriveClient({ getToken: () => 't', fetchImpl: drive.fetch });
  assert.equal(await again.ensurePath(['כספים', 'רכב']), id1);
  assert.equal(drive.nodes.filter((n) => n.name === 'רכב').length, 1);
});

test('סידור קבצים שכבר בדרייב (שטוחים): מועברים לתיקיות הנכונות ומקבלים את שמם האמיתי', async () => {
  const { drive, client } = setup();
  const data = mkData();
  for (const k of ['k1', 'k2', 'k3', 'k4']) drive.add({ name: 'raw-' + k, parents: ['FLAT'], props: { docflowKey: k } });
  const r = await client.placeFiles(planFiles(data, live(data)));
  assert.equal(r.moved, 3); assert.equal(r.uploaded, 0);
  const parentName = (k: string): string => drive.nodes.find((n) => n.id === drive.nodes.find((x) => x.props.docflowKey === k)!.parents[0])!.name;
  assert.equal(parentName('k1'), 'כספים'); assert.equal(parentName('k2'), '2026'); assert.equal(parentName('k3'), 'חשבוניות');
  assert.equal(drive.nodes.find((n) => n.props.docflowKey === 'k2')!.name, 'a.png');
  assert.equal(drive.nodes.find((n) => n.props.docflowKey === 'k4')!.parents[0], 'FLAT'); // מסמך שנמחק לא נוגעים בו
});

test('הרצה חוזרת לא כותבת כלום (עם זיכרון סידור)', async () => {
  const { drive, client } = setup();
  const data = mkData(); const layout = memLayout();
  for (const k of ['k1', 'k2', 'k3']) drive.add({ name: 'raw', parents: ['FLAT'], props: { docflowKey: k } });
  await client.placeFiles(planFiles(data, live(data)), { layout });
  drive.writes.length = 0;
  const r = await client.placeFiles(planFiles(data, live(data)), { layout });
  assert.equal(drive.writes.length, 0); assert.equal(r.moved, 0);
  // גם בלי זיכרון (force): בודק, אבל לא מזיז קבצים שכבר במקומם
  const forced = await client.placeFiles(planFiles(data, live(data)), { force: true });
  assert.equal(forced.moved, 0); assert.equal(forced.unchanged, 3); assert.equal(drive.writes.length, 0);
});

test('מעבר מסמך בין תיקיות ושינוי שם באפליקציה מעביר/משנה שם גם בדרייב', async () => {
  const { drive, client } = setup();
  const data = mkData(); const layout = memLayout();
  for (const k of ['k1', 'k2', 'k3']) drive.add({ name: 'raw', parents: ['FLAT'], props: { docflowKey: k } });
  await client.placeFiles(planFiles(data, live(data)), { layout });
  const changed = normalizeAppData({ ...data, documents: data.documents.map((d) => (d.id === 'd2' ? { ...d, folderId: 'a', fileName: 'new name.png' } : d)) });
  const r = await client.placeFiles(planFiles(changed, live(changed)), { layout });
  assert.equal(r.moved, 1);
  const n = drive.nodes.find((x) => x.props.docflowKey === 'k2')!;
  assert.equal(n.name, 'new name.png');
  assert.equal(drive.nodes.find((x) => x.id === n.parents[0])!.name, 'חשבוניות');
});

test('קובץ שלא בדרייב: מעלים אותו ישר לתיקיה הנכונה; בלי תוכן מקומי נספר כחסר', async () => {
  const { drive, client } = setup();
  const data = mkData();
  const blobs: Record<string, Blob> = { k1: new Blob(['one']), k2: new Blob(['two']) };
  const r = await client.placeFiles(planFiles(data, live(data)), { getBlob: async (k) => blobs[k] ?? null });
  assert.equal(r.uploaded, 2); assert.equal(r.missing, 1); // k3 אין לו תוכן
  const f2 = drive.nodes.find((n) => n.props.docflowKey === 'k2')!;
  assert.equal(drive.nodes.find((n) => n.id === f2.parents[0])!.name, '2026');
  assert.equal(await (f2.blob as Blob).text(), 'two');
  const noBlob = await client.placeFiles(planFiles(data, live(data)));
  assert.equal(noBlob.waitingUpload, 1); // k3 עדיין לא הועלה
});

test('שמות זהים באותה תיקיה: (2) ויציב', async () => {
  const { drive, client } = setup();
  const data = normalizeAppData({ categories: [{ id: 'c', name: 'ק' }], documents: [
    { id: 'x1', title: 'א', categoryId: 'c', fileKey: 'p1', fileName: 'b.pdf' }, { id: 'x2', title: 'ב', categoryId: 'c', fileKey: 'p2', fileName: 'b.pdf' }] });
  drive.add({ name: 'r1', props: { docflowKey: 'p1' } }); drive.add({ name: 'r2', props: { docflowKey: 'p2' } });
  await client.placeFiles(planFiles(data, live(data)));
  assert.deepEqual(drive.nodes.filter((n) => n.props.docflowKey).map((n) => n.name).sort(), ['b (2).pdf', 'b.pdf']);
});

test('גרסאות קודמות נכנסות לתיקיית "גרסאות קודמות"', async () => {
  const { drive, client } = setup();
  const data = mkData();
  drive.add({ name: 'old', props: { docflowKey: 'old3' } }); drive.add({ name: 'cur', props: { docflowKey: 'k3' } });
  await client.placeFiles(planFiles(data, live(data).filter((d) => d.id === 'd3'), true));
  const oldNode = drive.nodes.find((n) => n.props.docflowKey === 'old3')!;
  assert.equal(drive.nodes.find((n) => n.id === oldNode.parents[0])!.name, 'גרסאות קודמות');
  assert.equal(oldNode.name, 'b (v1.0).pdf');
});

test('הרשאות: בלי טוקן / טוקן פג -> DriveAuthError', async () => {
  const drive = new FakeDrive();
  await assert.rejects(new DriveClient({ getToken: () => null, fetchImpl: drive.fetch }).findMeta(), DriveAuthError);
  await assert.rejects(new DriveClient({ getToken: () => 'old', fetchImpl: drive.fetch }).findMeta(), (e: unknown) => e instanceof DriveAuthError);
});

test('קובץ הנתונים: יצירה, קריאה, עדכון וזמן עדכון', async () => {
  const { drive, client } = setup();
  assert.equal(await client.findMeta(), null);
  const id = await client.writeMeta(null, { hello: 1 }, 1000);
  assert.deepEqual(await client.findMeta(), { id, updatedAt: 1000 });
  assert.deepEqual(await client.readMeta(id), { hello: 1 } as unknown);
  await client.writeMeta(id, { hello: 2 }, 2000);
  assert.equal((await client.findMeta())!.updatedAt, 2000);
  assert.equal(drive.nodes.filter((n) => n.props.docflowMeta).length, 1);
});

test('הורדה לפי מפתח ומחיקה (לסל של דרייב)', async () => {
  const { drive, client } = setup();
  drive.add({ name: 'f', props: { docflowKey: 'kk' }, blob: new Blob(['data']) });
  assert.equal(await (await client.downloadByKey('kk'))!.text(), 'data');
  assert.equal(await client.downloadByKey('nope'), null);
  await client.trashByKey('kk');
  assert.equal(await client.findByKey('kk'), null);
});

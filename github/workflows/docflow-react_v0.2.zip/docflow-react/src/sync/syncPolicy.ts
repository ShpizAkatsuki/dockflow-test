/**
 * מדיניות הסנכרון (כניסה = קריאה בלבד).
 * כותבים לדרייב רק כשיש שינויים שהמשתמש עשה ועדיין לא עלו (pending),
 * או בהעלאה ראשונה של נתונים קיימים. בכל מצב אחר רק קוראים.
 */
export interface SyncInputs {
  hasRemote: boolean;
  remoteTs: number;
  localTs: number;
  /** יש שינויים שנעשו במכשיר הזה ועדיין לא הועלו */
  pending: boolean;
  /** המכשיר כבר סונכרן בעבר עם החשבון הזה */
  linked: boolean;
  hasLocalData: boolean;
}
export type SyncAction = 'nothing' | 'push' | 'apply-remote' | 'ask-link' | 'ask-conflict';

export function decideSync(i: SyncInputs): SyncAction {
  if (!i.hasRemote) return i.pending || i.hasLocalData ? 'push' : 'nothing';
  if (!i.linked) return i.hasLocalData && i.remoteTs !== i.localTs ? 'ask-link' : 'apply-remote';
  if (i.pending) return i.remoteTs > i.localTs ? 'ask-conflict' : 'push';
  return i.remoteTs > i.localTs ? 'apply-remote' : 'nothing';
}

/** תשובת המשתמש לשאלה (ask-link / ask-conflict) */
export const resolveAsk = (useCloud: boolean): 'apply-remote' | 'push' => (useCloud ? 'apply-remote' : 'push');

/** בדיקה ברקע (poll): מציגים נתונים חדשים מהענן רק אם אין שינויים מקומיים שממתינים */
export const shouldApplyOnPoll = (remoteTs: number, localTs: number, pending: boolean): boolean => remoteTs > localTs && !pending;

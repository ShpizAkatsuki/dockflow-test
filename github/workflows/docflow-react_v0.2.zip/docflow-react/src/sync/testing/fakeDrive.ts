/** דרייב מדומה לבדיקות: מממש את החלק של Google Drive API שהאפליקציה משתמשת בו */
export interface FakeNode { id: string; name: string; parents: string[]; mime: string; props: Record<string, string>; blob?: Blob; trashed: boolean }

export class FakeDrive {
  nodes: FakeNode[] = [];
  writes: string[] = [];
  token = 't';
  private n = 1;
  private pending: { name: string; parents: string[]; mime: string; props: Record<string, string> } | null = null;

  add(partial: Partial<FakeNode> & { name: string }): FakeNode {
    const node: FakeNode = { id: 'N' + this.n++, parents: [], mime: 'application/octet-stream', props: {}, trashed: false, ...partial };
    this.nodes.push(node);
    return node;
  }
  byName = (name: string): FakeNode | undefined => this.nodes.find((x) => x.name === name && !x.trashed);

  fetch = async (input: string | URL | Request, init: RequestInit = {}): Promise<Response> => {
    const url = new URL(String(input));
    const method = (init.method ?? 'GET').toUpperCase();
    const json = (o: unknown, headers?: Record<string, string>): Response => new Response(JSON.stringify(o), { status: 200, headers });
    const auth = (init.headers as Record<string, string> | undefined)?.Authorization;
    if (url.hostname !== 'upload.fake' && auth !== 'Bearer ' + this.token) return new Response('unauthorized', { status: 401 });

    if (url.hostname === 'upload.fake' && method === 'PUT') {
      const p = this.pending!;
      const node = this.add({ name: p.name, parents: p.parents, mime: p.mime, props: p.props, blob: init.body as Blob });
      this.writes.push('upload ' + p.name);
      return json({ id: node.id });
    }
    const isUpload = url.pathname.startsWith('/upload/');
    const idMatch = url.pathname.match(/\/files\/([^/]+)$/);
    const id = idMatch?.[1];

    if (method === 'POST' && isUpload) {
      const b = JSON.parse(String(init.body)) as { name: string; parents?: string[]; mimeType: string; appProperties?: Record<string, string> };
      this.pending = { name: b.name, parents: b.parents ?? [], mime: b.mimeType, props: b.appProperties ?? {} };
      return new Response('{}', { headers: { Location: 'https://upload.fake/1' } });
    }
    if (method === 'POST') {
      const b = JSON.parse(String(init.body)) as { name: string; parents?: string[]; mimeType: string; appProperties?: Record<string, string> };
      const node = this.add({ name: b.name, parents: b.parents ?? [], mime: b.mimeType, props: b.appProperties ?? {} });
      this.writes.push('folder ' + b.name);
      return json({ id: node.id });
    }
    if (method === 'PATCH') {
      const node = this.nodes.find((x) => x.id === id);
      if (!node) return new Response('not found', { status: 404 });
      if (isUpload) { node.blob = new Blob([String(init.body)]); this.writes.push('content ' + node.name); return json({ id }); }
      const body = init.body ? (JSON.parse(String(init.body)) as { name?: string; trashed?: boolean; appProperties?: Record<string, string> }) : {};
      const add = url.searchParams.get('addParents'), rem = url.searchParams.get('removeParents');
      if (add) node.parents = [...node.parents.filter((p) => !(rem ?? '').split(',').includes(p)), add];
      if (body.name) node.name = body.name;
      if (body.trashed) node.trashed = true;
      if (body.appProperties) node.props = { ...node.props, ...body.appProperties };
      this.writes.push('patch ' + node.name);
      return json({ id });
    }
    // GET
    if (id) {
      const node = this.nodes.find((x) => x.id === id);
      if (!node) return new Response('not found', { status: 404 });
      if (url.searchParams.get('alt') === 'media') return new Response(node.blob ?? '');
      return json({ id: node.id, name: node.name, parents: node.parents, appProperties: node.props });
    }
    const q = url.searchParams.get('q') ?? '';
    const ap = q.match(/appProperties has \{ key='([^']+)' and value='([^']*)' \}/);
    const nm = q.match(/name='((?:[^'\\]|\\.)*)'/);
    const par = q.match(/'([^']+)' in parents/);
    const folderOnly = q.includes("mimeType='application/vnd.google-apps.folder'");
    const files = this.nodes.filter((n) => !n.trashed
      && (!ap || n.props[ap[1] as string] === ap[2])
      && (!nm || n.name === (nm[1] as string).replace(/\\(.)/g, '$1'))
      && (!par || n.parents.includes(par[1] as string))
      && (!folderOnly || n.mime === 'application/vnd.google-apps.folder'));
    return json({ files: files.slice(0, 1).map((n) => ({ id: n.id, name: n.name, parents: n.parents, appProperties: n.props })) });
  };
}

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { decideSync, resolveAsk, shouldApplyOnPoll, type SyncInputs } from './syncPolicy.ts';

const base: SyncInputs = { hasRemote: true, remoteTs: 1000, localTs: 1000, pending: false, linked: true, hasLocalData: true };
const d = (o: Partial<SyncInputs>) => decideSync({ ...base, ...o });

test('כניסה בלי שינויים: לא כותבים כלום', () => assert.equal(d({}), 'nothing'));
test('בענן יש גרסה חדשה ואין שינויים מקומיים: מציגים אותה (בלי לכתוב)', () => assert.equal(d({ remoteTs: 2000 }), 'apply-remote'));
test('שינוי של המשתמש שעוד לא עלה: מעלים', () => assert.equal(d({ pending: true, localTs: 3000 }), 'push'));
test('שינוי מקומי וגם גרסה חדשה יותר בענן: שואלים את המשתמש', () => assert.equal(d({ pending: true, localTs: 3000, remoteTs: 5000 }), 'ask-conflict'));
test('אין קובץ בענן: מעלים רק אם יש מה להעלות', () => {
  assert.equal(d({ hasRemote: false, hasLocalData: false }), 'nothing');
  assert.equal(d({ hasRemote: false, hasLocalData: true }), 'push');
  assert.equal(d({ hasRemote: false, hasLocalData: false, pending: true }), 'push');
});
test('מכשיר שלא סונכרן עם החשבון: שואלים רק אם יש נתונים בשני הצדדים ושונים', () => {
  assert.equal(d({ linked: false, remoteTs: 1000, localTs: 1000 }), 'apply-remote');
  assert.equal(d({ linked: false, remoteTs: 1000, localTs: 2000 }), 'ask-link');
  assert.equal(d({ linked: false, hasLocalData: false, remoteTs: 9 }), 'apply-remote');
});
test('תשובת המשתמש', () => { assert.equal(resolveAsk(true), 'apply-remote'); assert.equal(resolveAsk(false), 'push'); });
test('בדיקה ברקע לא דורסת שינויים מקומיים', () => {
  assert.equal(shouldApplyOnPoll(2000, 1000, false), true);
  assert.equal(shouldApplyOnPoll(2000, 1000, true), false);
  assert.equal(shouldApplyOnPoll(1000, 1000, false), false);
});

import type { PlannedFile } from '../core/exportPlan.ts';

const API = 'https://www.googleapis.com/drive/v3/files';
const UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files';
const FOLDER = 'application/vnd.google-apps.folder';
/** תיקיית השורש של הקבצים המסודרים ב-Drive (אותו שם כמו בגרסה הוונילית, כדי שלא יהיה מעבר) */
export const DRIVE_ROOT_NAME = 'DocFlow - קבצים מסודרים';

export class DriveAuthError extends Error {
  readonly code = 'drive-auth';
  constructor(msg = 'drive-auth') { super(msg); this.name = 'DriveAuthError'; }
}
export class DriveHttpError extends Error {
  readonly status: number;
  constructor(status: number, msg: string) { super(msg); this.status = status; this.name = 'DriveHttpError'; }
  get code(): string { return 'drive-' + this.status; }
}

export interface LayoutStore { get(): Record<string, string>; set(v: Record<string, string>): void }
export interface PlaceOptions {
  /** מחזיר את תוכן הקובץ; בלעדיו רק מסדרים קבצים שכבר קיימים בדרייב */
  getBlob?: (key: string) => Promise<Blob | null>;
  /** זיכרון של מה כבר מסודר, כדי לא לבדוק הכול בכל שמירה */
  layout?: LayoutStore;
  force?: boolean;
  onProgress?: (n: number, total: number) => void;
}
export interface PlaceResult { total: number; uploaded: number; moved: number; unchanged: number; missing: number; waitingUpload: number }

interface DriveFile { id: string; name?: string; parents?: string[]; appProperties?: Record<string, string> }

export class DriveClient {
  private readonly folders = new Map<string, string>();
  private readonly deps: { getToken: () => string | null; fetchImpl?: typeof fetch };
  constructor(deps: { getToken: () => string | null; fetchImpl?: typeof fetch }) { this.deps = deps; }

  private async call(url: string, init: RequestInit = {}): Promise<Response> {
    const token = this.deps.getToken();
    if (!token) throw new DriveAuthError();
    const headers = { ...(init.headers as Record<string, string> | undefined), Authorization: 'Bearer ' + token };
    const res = await (this.deps.fetchImpl ?? fetch)(url, { ...init, headers });
    if (res.status === 401) throw new DriveAuthError('drive-expired');
    if (!res.ok) throw new DriveHttpError(res.status, `Drive ${res.status} ${(await res.text().catch(() => '')).slice(0, 160)}`);
    return res;
  }
  private static esc = (s: string): string => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

  private async list(query: string, fields: string, order = ''): Promise<DriveFile[]> {
    const url = `${API}?q=${encodeURIComponent(query)}${order ? '&orderBy=' + order : ''}&fields=files(${fields})&pageSize=1`;
    const r = (await (await this.call(url)).json()) as { files?: DriveFile[] };
    return r.files ?? [];
  }

  /** תיקיה בתוך תיקיית אב (או תיקיית השורש כש-parentId הוא null). יוצר אם אין. */
  async ensureFolder(parentId: string | null, name: string): Promise<string> {
    const ck = (parentId ?? 'root') + '/' + name;
    const cached = this.folders.get(ck);
    if (cached) return cached;
    const body: Record<string, unknown> = { name, mimeType: FOLDER };
    let query: string;
    if (parentId) { query = `mimeType='${FOLDER}' and name='${DriveClient.esc(name)}' and '${parentId}' in parents and trashed=false`; body.parents = [parentId]; }
    else { query = "appProperties has { key='docflowExportRoot' and value='1' } and trashed=false"; body.name = DRIVE_ROOT_NAME; body.appProperties = { docflowExportRoot: '1' }; }
    const found = await this.list(query, 'id', 'createdTime');
    let id = found[0]?.id;
    if (!id) {
      const c = (await (await this.call(`${API}?fields=id`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })).json()) as DriveFile;
      id = c.id;
    }
    this.folders.set(ck, id);
    return id;
  }
  async ensurePath(dirs: readonly string[]): Promise<string> {
    let parent = await this.ensureFolder(null, DRIVE_ROOT_NAME);
    for (const d of dirs) parent = await this.ensureFolder(parent, d);
    return parent;
  }

  async findByKey(key: string): Promise<string | null> {
    const k = key.replace(/['\\]/g, '');
    const f = await this.list(`appProperties has { key='docflowKey' and value='${k}' } and trashed=false`, 'id');
    return f[0]?.id ?? null;
  }
  async downloadByKey(key: string): Promise<Blob | null> {
    const id = await this.findByKey(key);
    return id ? await (await this.call(`${API}/${id}?alt=media`)).blob() : null;
  }
  async trashByKey(key: string): Promise<void> {
    const id = await this.findByKey(key);
    if (id) await this.call(`${API}/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ trashed: true }) });
  }

  private async createFile(parent: string, name: string, blob: Blob, key: string): Promise<string> {
    const type = blob.type || 'application/octet-stream';
    const init = await this.call(`${UPLOAD}?uploadType=resumable&fields=id`, {
      method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': type },
      body: JSON.stringify({ name, parents: [parent], mimeType: type, appProperties: { docflowKey: key } })
    });
    const loc = init.headers.get('Location');
    if (!loc) throw new Error('drive-no-upload-url');
    const up = await (this.deps.fetchImpl ?? fetch)(loc, { method: 'PUT', headers: { 'Content-Type': type }, body: blob });
    if (!up.ok) throw new DriveHttpError(up.status, 'Drive upload ' + up.status);
    return ((await up.json()) as DriveFile).id;
  }

  /**
   * מציב קבצים במקום הנכון בדרייב: מעלה קבצים חסרים לתיקייה הנכונה, ומעביר / משנה שם לקבצים שכבר קיימים.
   * בטוח להריץ שוב ושוב: קובץ שכבר במקומו לא נוגעים בו.
   */
  async placeFiles(items: readonly PlannedFile[], opts: PlaceOptions = {}): Promise<PlaceResult> {
    const saved = opts.force || !opts.layout ? {} : opts.layout.get();
    const todo = items.filter((it) => saved[it.key] !== it.sig);
    const res: PlaceResult = { total: items.length, uploaded: 0, moved: 0, unchanged: 0, missing: 0, waitingUpload: 0 };
    const done: Record<string, string> = {};
    for (let i = 0; i < todo.length; i++) {
      const it = todo[i] as PlannedFile;
      const id = await this.findByKey(it.key);
      if (!id) {
        if (!opts.getBlob) res.waitingUpload++;
        else {
          const blob = await opts.getBlob(it.key);
          if (!blob) res.missing++;
          else { await this.createFile(await this.ensurePath(it.dirs), it.name, blob, it.key); res.uploaded++; done[it.key] = it.sig; }
        }
      } else {
        const info = (await (await this.call(`${API}/${id}?fields=id,name,parents`)).json()) as DriveFile;
        const parent = await this.ensurePath(it.dirs);
        const parents = info.parents ?? [];
        const wrongPlace = !parents.includes(parent), wrongName = info.name !== it.name;
        if (wrongPlace || wrongName) {
          let url = `${API}/${id}?fields=id`;
          if (wrongPlace) { url += '&addParents=' + parent; if (parents.length) url += '&removeParents=' + parents.join(','); }
          await this.call(url, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(wrongName ? { name: it.name } : {}) });
          res.moved++;
        } else res.unchanged++;
        done[it.key] = it.sig;
      }
      opts.onProgress?.(i + 1, todo.length);
    }
    if (opts.layout) {
      const keep: Record<string, string> = {};
      for (const it of items) { const s = done[it.key] ?? saved[it.key]; if (s === it.sig) keep[it.key] = s; }
      opts.layout.set(keep);
    }
    return res;
  }

  // ---------- קובץ הנתונים (JSON אחד לכל משתמש) ----------
  async findMeta(): Promise<{ id: string; updatedAt: number } | null> {
    const f = await this.list("appProperties has { key='docflowMeta' and value='1' } and trashed=false", 'id,appProperties', 'createdTime');
    const m = f[0];
    return m ? { id: m.id, updatedAt: Number(m.appProperties?.updatedAt ?? 0) } : null;
  }
  async readMeta<T>(id: string): Promise<T> { return (await (await this.call(`${API}/${id}?alt=media`)).json()) as T; }
  async writeMeta(id: string | null, payload: unknown, ts: number): Promise<string> {
    const body = JSON.stringify(payload);
    if (id) {
      await this.call(`${UPLOAD}/${id}?uploadType=media`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body });
      await this.call(`${API}/${id}?fields=id`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ appProperties: { updatedAt: String(ts) } }) });
      return id;
    }
    const parent = await this.ensureFolder(null, DRIVE_ROOT_NAME);
    const init = await this.call(`${UPLOAD}?uploadType=resumable&fields=id`, {
      method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'docflow-data.json', parents: [parent], mimeType: 'application/json', appProperties: { docflowMeta: '1', updatedAt: String(ts) } })
    });
    const loc = init.headers.get('Location');
    if (!loc) throw new Error('drive-no-upload-url');
    const up = await (this.deps.fetchImpl ?? fetch)(loc, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body });
    if (!up.ok) throw new DriveHttpError(up.status, 'Drive upload ' + up.status);
    return ((await up.json()) as DriveFile).id;
  }
}

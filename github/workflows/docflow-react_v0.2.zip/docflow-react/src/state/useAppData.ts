import { useCallback, useState } from 'react';
import type { AppData } from '../core/types.ts';
import { emptyData, normalizeAppData } from '../core/normalize.ts';

// אותם מפתחות כמו באפליקציה הקיימת: הגרסה החדשה קוראת את הנתונים שכבר שמורים בדפדפן
const DATA_KEY = 'docflow_saas_data';

export function loadAppData(): AppData {
  try {
    const raw = localStorage.getItem(DATA_KEY);
    return raw ? normalizeAppData(JSON.parse(raw)) : emptyData();
  } catch {
    return emptyData();
  }
}

/** שמירה = פעולת משתמש: מסמנים "שינויים ממתינים" כדי שהסנכרון יעלה אותם (כניסה לאפליקציה לא כותבת לדרייב) */
export function saveAppData(next: AppData): void {
  try {
    localStorage.setItem(DATA_KEY, JSON.stringify(next));
    localStorage.setItem('docflow_updated', String(Date.now()));
    localStorage.setItem('docflow_pending', '1');
  } catch {
    // אחסון מלא: המסך יציג הודעה בשלב הבא
  }
}

export function useAppData() {
  const [data, setData] = useState<AppData>(loadAppData);
  const update = useCallback((fn: (d: AppData) => AppData) => {
    setData((prev) => {
      const next = fn(prev);
      saveAppData(next);
      return next;
    });
  }, []);
  return { data, update };
}

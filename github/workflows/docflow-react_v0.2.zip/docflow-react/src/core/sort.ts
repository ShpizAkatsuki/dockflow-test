import type { Category, DocItem, SortMode } from './types.ts';
import { idTime } from './ids.ts';

const newer = (x: DocItem, y: DocItem): number => (y.date || '').localeCompare(x.date || '') || idTime(y.id) - idTime(x.id);

export function sortDocs(docs: readonly DocItem[], mode: SortMode): DocItem[] {
  const a = [...docs];
  if (mode === 'manual') a.sort((x, y) => (x.order == null && y.order == null ? newer(x, y) : x.order == null ? -1 : y.order == null ? 1 : x.order - y.order));
  else if (mode === 'name') a.sort((x, y) => x.title.localeCompare(y.title, 'he'));
  else if (mode === 'name-desc') a.sort((x, y) => y.title.localeCompare(x.title, 'he'));
  else if (mode === 'date-asc') a.sort((x, y) => -newer(x, y));
  else a.sort(newer);
  return a;
}

/** תיקיות ותתי-קטגוריות: ידני = סדר המערך; תאריך = זמן היצירה מתוך ה-id */
export function sortNamed<T extends { id: string; name: string }>(items: readonly T[], mode: SortMode): T[] {
  const a = [...items];
  if (mode === 'name') a.sort((x, y) => x.name.localeCompare(y.name, 'he'));
  else if (mode === 'name-desc') a.sort((x, y) => y.name.localeCompare(x.name, 'he'));
  else if (mode === 'date-asc') a.sort((x, y) => idTime(x.id) - idTime(y.id));
  else if (mode === 'date-desc') a.sort((x, y) => idTime(y.id) - idTime(x.id));
  return a;
}

/** מחליף פריט עם השכן שלו בתוך אותה קבוצה (dir = -1 קדימה, +1 אחורה). מחזיר מערך חדש, או null אם אין לאן לזוז */
export function moveWithin<T>(all: readonly T[], isSibling: (x: T) => boolean, item: T, dir: -1 | 1): T[] | null {
  const sibs = all.filter(isSibling);
  const other = sibs[sibs.indexOf(item) + dir];
  if (!other) return null;
  const out = [...all];
  const i = out.indexOf(item), j = out.indexOf(other);
  [out[i], out[j]] = [out[j] as T, out[i] as T];
  return out;
}

/** סדר ידני למסמכים: נותן מספר סדר לכל הרשימה המוצגת ומחליף שני שכנים. מחזיר id -> order */
export function reorderDocs(displayed: readonly DocItem[], id: string, dir: -1 | 1): Map<string, number> | null {
  const i = displayed.findIndex((d) => d.id === id);
  const other = displayed[i + dir];
  if (i < 0 || !other) return null;
  const order = new Map(displayed.map((d, k) => [d.id, k] as const));
  const a = order.get(id) as number, b = order.get(other.id) as number;
  order.set(id, b); order.set(other.id, a);
  return order;
}

/** קטגוריות מסומנות בכוכב ראשונות; בתוך כל קבוצה נשמר הסדר הידני */
export const sortedCategories = (cats: readonly Category[]): Category[] =>
  [...cats.filter((c) => c.isFavorite), ...cats.filter((c) => !c.isFavorite)];

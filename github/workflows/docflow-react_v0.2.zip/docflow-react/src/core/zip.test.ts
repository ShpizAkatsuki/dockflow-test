import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildZip, crc32 } from './zip.ts';

/** קורא ZIP (STORE) בעצמנו: לא תלוי בתוכנת unzip ובהגדרות השפה של המערכת */
function readZip(buf: Uint8Array): { name: string; data: Uint8Array; crc: number; utf8: boolean }[] {
  const v = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0; i--) if (v.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  assert.notEqual(eocd, -1);
  const count = v.getUint16(eocd + 10, true);
  let p = v.getUint32(eocd + 16, true);
  const out: { name: string; data: Uint8Array; crc: number; utf8: boolean }[] = [];
  for (let n = 0; n < count; n++) {
    assert.equal(v.getUint32(p, true), 0x02014b50);
    const flags = v.getUint16(p + 8, true), crc = v.getUint32(p + 16, true), size = v.getUint32(p + 24, true);
    const nameLen = v.getUint16(p + 28, true), extraLen = v.getUint16(p + 30, true), commentLen = v.getUint16(p + 32, true);
    const local = v.getUint32(p + 42, true);
    const name = new TextDecoder().decode(buf.subarray(p + 46, p + 46 + nameLen));
    assert.equal(v.getUint32(local, true), 0x04034b50);
    const start = local + 30 + v.getUint16(local + 26, true) + v.getUint16(local + 28, true);
    out.push({ name, data: buf.subarray(start, start + size), crc, utf8: (flags & 0x0800) !== 0 });
    p += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

test('crc32 של "123456789" הוא הערך הסטנדרטי', () => {
  assert.equal(crc32(new TextEncoder().encode('123456789')), 0xcbf43926);
});

test('ZIP עם שמות בעברית ותיקיות: שמות, תוכן ו-CRC נכונים', async () => {
  const zip = await buildZip([
    { name: 'dockflow/כספים/רכב/חשבונית.pdf', blob: new Blob(['PDF-DATA']) },
    { name: 'dockflow/אחר/x.txt', blob: new Blob(['hello']) }
  ]);
  const files = readZip(new Uint8Array(await zip.arrayBuffer()));
  assert.deepEqual(files.map((f) => f.name), ['dockflow/כספים/רכב/חשבונית.pdf', 'dockflow/אחר/x.txt']);
  assert.equal(new TextDecoder().decode(files[0]!.data), 'PDF-DATA');
  assert.equal(new TextDecoder().decode(files[1]!.data), 'hello');
  for (const f of files) { assert.equal(f.crc, crc32(f.data)); assert.equal(f.utf8, true); }
});

test('ZIP ריק ו-ZIP עם קובץ ריק תקינים', async () => {
  assert.equal(readZip(new Uint8Array(await (await buildZip([])).arrayBuffer())).length, 0);
  const one = readZip(new Uint8Array(await (await buildZip([{ name: 'a.txt', blob: new Blob([]) }])).arrayBuffer()));
  assert.equal(one[0]!.data.length, 0);
});

// בדיקת שלמות נוספת עם unzip (אם מותקן). בודקים רק את קוד היציאה, בלי להסתמך על שמות הקבצים.
const hasUnzip = spawnSync('unzip', ['-v']).status === 0;
test('unzip -t מאשר שה-ZIP תקין', { skip: !hasUnzip && 'unzip לא מותקן' }, async () => {
  const zip = await buildZip([{ name: 'dockflow/כספים/a.txt', blob: new Blob(['x']) }]);
  const dir = mkdtempSync(join(tmpdir(), 'zip-'));
  const f = join(dir, 'a.zip');
  writeFileSync(f, new Uint8Array(await zip.arrayBuffer()));
  execFileSync('unzip', ['-tq', f]);
});

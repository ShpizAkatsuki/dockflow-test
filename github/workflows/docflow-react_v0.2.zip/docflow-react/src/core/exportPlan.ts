import type { AppData, DocItem } from './types.ts';
import { descendantFolderIds, docDirs, uniqueName, zipSafe } from './tree.ts';

export const EXPORT_ROOT = 'dockflow';
export const OLD_VERSIONS_DIR = 'גרסאות קודמות';

export type ExportScope =
  | { kind: 'all' }
  | { kind: 'cat'; id: string }
  | { kind: 'sub'; catId: string; id: string }
  | { kind: 'folder'; catId: string; id: string };

/** המסמכים (שלא נמחקו) של קטגוריה / תת-קטגוריה / תיקיה / הכול */
export function docsForScope(data: AppData, scope: ExportScope): { name: string; docs: DocItem[] } | null {
  const live = data.documents.filter((d) => !d.isDeleted);
  if (scope.kind === 'all') return { name: EXPORT_ROOT, docs: live };
  const catId = scope.kind === 'cat' ? scope.id : scope.catId;
  const cat = data.categories.find((c) => c.id === catId);
  if (!cat) return null;
  const mine = live.filter((d) => d.categoryId === cat.id);
  if (scope.kind === 'cat') return { name: cat.name, docs: mine };
  if (scope.kind === 'sub') { const sb = cat.subs.find((s) => s.id === scope.id); return sb ? { name: sb.name, docs: mine.filter((d) => d.subId === sb.id) } : null; }
  const f = cat.folders.find((x) => x.id === scope.id);
  if (!f) return null;
  const ids = [f.id, ...descendantFolderIds(cat, f.id)];
  return { name: f.name, docs: mine.filter((d) => ids.includes(d.folderId)) };
}

export interface PlannedFile {
  key: string; dirs: string[]; name: string; sig: string; kind: 'current' | 'version'; docId: string;
}
export const layoutSig = (dirs: string[], name: string): string => dirs.join('/') + '/|' + name;

const versionName = (fileName: string, version: string): string => {
  const f = zipSafe(fileName); const dot = f.lastIndexOf('.');
  return dot > 0 ? `${f.slice(0, dot)} (${version})${f.slice(dot)}` : `${f} (${version})`;
};

/**
 * תוכנית המיקום של קבצים: איפה כל קובץ יושב (קטגוריה/תת-קטגוריה/תיקיה) ובאיזה שם.
 * משמשת גם ל-ZIP בטלפון וגם לסידור בדרייב, כדי ששניהם יראו אותו דבר.
 */
export function planFiles(data: AppData, docs: readonly DocItem[], includeVersions = false): PlannedFile[] {
  const used = new Set<string>(); const out: PlannedFile[] = [];
  for (const d of docs) {
    if (!d.fileKey) continue;
    const cat = data.categories.find((c) => c.id === d.categoryId);
    const dirs = docDirs(cat, d);
    const name = uniqueName(used, dirs, zipSafe(d.fileName || d.title));
    out.push({ key: d.fileKey, dirs, name, sig: layoutSig(dirs, name), kind: 'current', docId: d.id });
    if (includeVersions) {
      for (const v of d.versions) {
        if (!v.fileKey || v.fileKey === d.fileKey) continue;
        const vDirs = [...dirs, OLD_VERSIONS_DIR];
        const vName = uniqueName(used, vDirs, versionName(v.fileName || d.title, v.version));
        out.push({ key: v.fileKey, dirs: vDirs, name: vName, sig: layoutSig(vDirs, vName), kind: 'version', docId: d.id });
      }
    }
  }
  return out;
}

export const zipPath = (f: Pick<PlannedFile, 'dirs' | 'name'>, root: string = EXPORT_ROOT): string => [root, ...f.dirs, f.name].join('/');

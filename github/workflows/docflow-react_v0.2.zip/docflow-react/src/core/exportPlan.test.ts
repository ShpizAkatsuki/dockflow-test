import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeAppData } from './normalize.ts';
import { docsForScope, planFiles, zipPath } from './exportPlan.ts';

const data = normalizeAppData({
  categories: [
    { id: 'c1', name: 'כספים', subs: [{ id: 's', name: 'רכב' }], folders: [{ id: 'a', name: 'חשבוניות', subId: 's' }, { id: 'b', name: '2026', parentId: 'a' }] },
    { id: 'c2', name: 'אחר' }
  ],
  documents: [
    { id: 'd1', title: 'שורש', categoryId: 'c1', fileKey: 'k1', fileName: 'root.txt' },
    { id: 'd2', title: 'עמוק', categoryId: 'c1', folderId: 'b', fileKey: 'k2', fileName: 'a.png' },
    { id: 'd3', title: 'כפול', categoryId: 'c1', folderId: 'b', fileKey: 'k3', fileName: 'a.png',
      versions: [{ version: 'v1.0', fileKey: 'old', fileName: 'a.png' }, { version: 'v2.0', fileKey: 'k3', fileName: 'a.png' }] },
    { id: 'd4', title: 'נמחק', categoryId: 'c2', fileKey: 'k4', fileName: 'z.docx', isDeleted: true },
    { id: 'd5', title: 'בלי קובץ', categoryId: 'c2' }
  ]
});

test('היקפים: הכול / קטגוריה / תת-קטגוריה / תיקיה (עם תתי-תיקיות); מסמכים שנמחקו לא נכללים', () => {
  assert.equal(docsForScope(data, { kind: 'all' })!.docs.length, 4);
  assert.deepEqual(docsForScope(data, { kind: 'cat', id: 'c1' })!.docs.map((d) => d.id), ['d1', 'd2', 'd3']);
  assert.deepEqual(docsForScope(data, { kind: 'sub', catId: 'c1', id: 's' })!.docs.map((d) => d.id), ['d2', 'd3']);
  assert.deepEqual(docsForScope(data, { kind: 'folder', catId: 'c1', id: 'a' })!.docs.map((d) => d.id), ['d2', 'd3']);
  assert.equal(docsForScope(data, { kind: 'cat', id: 'nope' }), null);
});
test('תוכנית קבצים: נתיב לפי קטגוריה/תת-קטגוריה/תיקיה, שמות כפולים מקבלים (2)', () => {
  const plan = planFiles(data, docsForScope(data, { kind: 'all' })!.docs);
  assert.deepEqual(plan.map((p) => zipPath(p)), [
    'dockflow/כספים/root.txt', 'dockflow/כספים/רכב/חשבוניות/2026/a.png', 'dockflow/כספים/רכב/חשבוניות/2026/a (2).png']);
});
test('גרסאות קודמות נכנסות לתיקיית "גרסאות קודמות" רק כשמבקשים', () => {
  const docs = docsForScope(data, { kind: 'cat', id: 'c1' })!.docs;
  assert.equal(planFiles(data, docs).some((p) => p.kind === 'version'), false);
  const withV = planFiles(data, docs, true).filter((p) => p.kind === 'version');
  assert.equal(withV.length, 1);
  assert.equal(withV[0]!.key, 'old');
  assert.equal(zipPath(withV[0]!), 'dockflow/כספים/רכב/חשבוניות/2026/גרסאות קודמות/a (v1.0).png');
});
test('החתימה (sig) משתנה כשמסמך עובר תיקיה או משנה שם', () => {
  const before = planFiles(data, data.documents.filter((d) => d.id === 'd2'))[0]!.sig;
  const moved = normalizeAppData({ ...data, documents: data.documents.map((d) => (d.id === 'd2' ? { ...d, folderId: 'a' } : d)) });
  assert.notEqual(planFiles(moved, moved.documents.filter((d) => d.id === 'd2'))[0]!.sig, before);
});

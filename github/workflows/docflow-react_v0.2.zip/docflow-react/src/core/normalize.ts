import type { AppData, Category, DocItem, Folder, Sub } from './types.ts';
import { safeIcon, uid } from './ids.ts';

export const emptyData = (): AppData => ({ categories: [], documents: [], tags: [] });
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const isValidData = (d: any): boolean => !!d && Array.isArray(d.categories) && Array.isArray(d.documents);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function normSubs(ss: any): Sub[] {
  const arr: any[] = Array.isArray(ss) ? ss.filter((x) => x && x.id) : [];
  return arr.map((x) => ({ id: String(x.id), name: x.name || 'ללא שם' }));
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function normFolders(fs: any, subs: Sub[]): Folder[] {
  const arr: any[] = Array.isArray(fs) ? fs.filter((f) => f && f.id) : [];
  const ids = new Set(arr.map((f) => String(f.id)));
  const subIds = new Set(subs.map((s) => s.id));
  const out: Folder[] = arr.map((f) => ({
    id: String(f.id), name: f.name || 'ללא שם',
    parentId: f.parentId && f.parentId !== f.id && ids.has(String(f.parentId)) ? String(f.parentId) : '',
    subId: subIds.has(f.subId) ? String(f.subId) : ''
  }));
  // תיקיית משנה שייכת לאותה תת-קטגוריה של תיקיית האב
  const byId = new Map(out.map((f) => [f.id, f] as const));
  const rootSub = (f: Folder): string => { let g = 0; let cur = f; while (cur.parentId && g++ < 50) { const p = byId.get(cur.parentId); if (!p) break; cur = p; } return cur.subId; };
  out.forEach((f) => { f.subId = rootSub(f); });
  return out;
}

/** מנרמל נתונים מכל גרסה ישנה של האפליקציה (כולל הגרסה הוונילית) למבנה הנוכחי */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function normalizeAppData(raw: any): AppData {
  if (!isValidData(raw)) return emptyData();
  const legacyTags: string[] = (Array.isArray(raw.tags) ? raw.tags : []).map((t: unknown) => String(t ?? '').trim()).filter(Boolean);

  const categories: Category[] = raw.categories.map((c: any): Category => {
    const subs = normSubs(c.subs);
    return {
      id: c.id || uid('cat'), name: c.name || 'ללא שם', description: c.description || '', icon: safeIcon(c.icon),
      isFavorite: !!c.isFavorite, subs, folders: normFolders(c.folders, subs),
      tags: Array.isArray(c.tags) ? c.tags.map(String) : []
    };
  });

  const documents: DocItem[] = raw.documents.map((x: any): DocItem => {
    const doc: DocItem = {
      id: x.id || uid('doc'), title: x.title || 'ללא שם', categoryId: x.categoryId || '', subId: x.subId || '', folderId: x.folderId || '',
      tags: Array.isArray(x.tags) ? x.tags.map(String) : [], content: x.content || '', date: x.date || '', size: x.size || '',
      fileName: x.fileName || '', fileKey: x.fileKey || '', fileType: x.fileType || 'other',
      versions: Array.isArray(x.versions) ? x.versions : [], isFavorite: !!x.isFavorite, isDeleted: !!x.isDeleted
    };
    if (x.deletedAt) doc.deletedAt = x.deletedAt;
    if (typeof x.order === 'number') doc.order = x.order;
    if (x.fileUrl) doc.fileUrl = x.fileUrl;
    // מסמכים שנוצרו בלי קובץ אמיתי: ללא שם קובץ / נפח / גרסאות מדומים
    if (!doc.fileKey && !doc.fileUrl) { doc.fileName = ''; doc.size = ''; doc.versions = []; }
    return doc;
  });

  // תגיות לפי קטגוריה: הספרייה של הקטגוריה + תגיות המסמכים שבה (+ תגיות גלובליות ישנות, פעם אחת)
  categories.forEach((c, i) => {
    const hadOwnTags = Array.isArray(raw.categories[i]?.tags);
    const lib: string[] = [];
    const add = (t: unknown): void => {
      const s = String(t ?? '').trim();
      if (s && !lib.some((x) => x.toLowerCase() === s.toLowerCase())) lib.push(s);
    };
    c.tags.forEach(add);
    documents.filter((d) => d.categoryId === c.id).forEach((d) => d.tags.forEach(add));
    if (!hadOwnTags) legacyTags.forEach(add);
    c.tags = lib;
  });

  documents.forEach((d) => {
    d.tags = d.tags.map((t) => t.trim()).filter(Boolean);
    const cat = categories.find((c) => c.id === d.categoryId);
    if (cat) d.tags = [...new Set(d.tags.map((t) => cat.tags.find((x) => x.toLowerCase() === t.toLowerCase()) ?? t))];
    if (d.folderId && !(cat && cat.folders.some((f) => f.id === d.folderId))) d.folderId = '';
    const fol = cat && d.folderId ? cat.folders.find((f) => f.id === d.folderId) : undefined;
    d.subId = fol ? fol.subId : cat && cat.subs.some((s) => s.id === d.subId) ? d.subId : '';
  });

  return { categories, documents, tags: [] };
}

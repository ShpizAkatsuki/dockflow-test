import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeAppData } from './normalize.ts';
import { descendantFolderIds, docDirs, folderChain, folderOptions, folderPath, uniqueName, zipSafe } from './tree.ts';

const data = normalizeAppData({
  categories: [{ id: 'c1', name: 'כספים', subs: [{ id: 's', name: 'רכב' }],
    folders: [{ id: 'a', name: 'חשבוניות', subId: 's' }, { id: 'b', name: '2026', parentId: 'a' }, { id: 'c', name: 'פנימי', parentId: 'b' }] }],
  documents: [{ id: 'd', title: 't', categoryId: 'c1', folderId: 'c', fileKey: 'k', fileName: 'x.pdf' }]
});
const cat = data.categories[0]!;

test('נתיב ושרשרת תיקיות', () => {
  assert.deepEqual(folderChain(cat, 'c'), ['חשבוניות', '2026', 'פנימי']);
  assert.equal(folderPath(cat, 'b'), 'חשבוניות › 2026');
  assert.deepEqual(folderChain(cat, ''), []);
});
test('צאצאים ואפשרויות (בלי הענף שמוחרג)', () => {
  assert.deepEqual(descendantFolderIds(cat, 'a'), ['b', 'c']);
  assert.deepEqual(folderOptions(cat, ['b']).map((o) => o.id), ['a']);
});
test('docDirs: קטגוריה > תת-קטגוריה > תיקיות', () => {
  assert.deepEqual(docDirs(cat, data.documents[0]!), ['כספים', 'רכב', 'חשבוניות', '2026', 'פנימי']);
  assert.deepEqual(docDirs(undefined, data.documents[0]!), []);
});
test('zipSafe מנקה תווים אסורים ולא מחזיר ריק', () => {
  assert.equal(zipSafe('a/b:c*d?.pdf'), 'a_b_c_d_.pdf');
  assert.equal(zipSafe('...'), 'ללא שם');
  assert.equal(zipSafe(null), 'ללא שם');
});
test('uniqueName: שם כפול באותה תיקיה מקבל (2), בתיקיה אחרת לא', () => {
  const used = new Set<string>();
  assert.equal(uniqueName(used, ['a'], 'b.pdf'), 'b.pdf');
  assert.equal(uniqueName(used, ['a'], 'B.pdf'), 'B (2).pdf');
  assert.equal(uniqueName(used, ['a'], 'b.pdf'), 'b (3).pdf');
  assert.equal(uniqueName(used, ['z'], 'b.pdf'), 'b.pdf');
  assert.equal(uniqueName(used, ['a'], 'noext'), 'noext');
  assert.equal(uniqueName(used, ['a'], 'noext'), 'noext (2)');
});

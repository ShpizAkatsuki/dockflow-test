import type { FileType } from './types.ts';

export const uid = (prefix: string): string =>
  prefix + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/** זמן היצירה מתוך ה-id (משמש למיון לפי תאריך). מזהים ישנים בלי זמן מחזירים מספר קטן */
export const idTime = (id: string): number => {
  const n = parseInt(String(id || '').split('-')[1] ?? '', 36);
  return Number.isFinite(n) ? n : 0;
};

const pad = (n: number): string => String(n).padStart(2, '0');
export const dateStr = (d: Date): string => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const today = (now: Date = new Date()): string => dateStr(now);
export const dateMinus = (n: number, now: Date = new Date()): string => { const d = new Date(now); d.setDate(d.getDate() - n); return dateStr(d); };
export const formatDate = (s: string): string => { if (!s) return ''; const [y, m, d] = s.split('-'); return `${d}/${m}/${y}`; };

export function formatSize(b: number): string {
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return Math.round(b / 1024) + ' KB';
  return (b / (1024 * 1024)).toFixed(1) + ' MB';
}

export function detectType(file: { name: string; type?: string }): FileType {
  const n = file.name.toLowerCase();
  if (n.endsWith('.pdf')) return 'pdf';
  if (n.endsWith('.doc') || n.endsWith('.docx')) return 'word';
  if (n.endsWith('.xls') || n.endsWith('.xlsx') || n.endsWith('.csv')) return 'excel';
  if ((file.type ?? '').startsWith('image/')) return 'image';
  return 'other';
}

export const safeIcon = (i: unknown): string => (typeof i === 'string' && /^fa-[a-z0-9-]+$/.test(i) ? i : 'fa-folder');

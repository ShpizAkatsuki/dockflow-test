export type FileType = 'pdf' | 'word' | 'excel' | 'image' | 'other';

export interface FileVersion { version: string; date: string; fileName: string; size: string; fileKey: string }

export interface DocItem {
  id: string; title: string; categoryId: string; subId: string; folderId: string;
  tags: string[]; content: string; date: string; size: string;
  fileName: string; fileKey: string; fileType: FileType;
  versions: FileVersion[]; isFavorite: boolean; isDeleted: boolean;
  deletedAt?: string; order?: number;
  /** base64 ישן, קיים רק לפני המעבר ל-IndexedDB */
  fileUrl?: string;
}

export interface Folder { id: string; name: string; parentId: string; subId: string }
export interface Sub { id: string; name: string }
export interface Category {
  id: string; name: string; description: string; icon: string; isFavorite: boolean;
  subs: Sub[]; folders: Folder[]; tags: string[];
}
export interface AppData { categories: Category[]; documents: DocItem[]; tags: string[] }

export const SORT_MODES = ['manual', 'name', 'name-desc', 'date-desc', 'date-asc'] as const;
export type SortMode = (typeof SORT_MODES)[number];
export const isSortMode = (v: unknown): v is SortMode => typeof v === 'string' && (SORT_MODES as readonly string[]).includes(v);

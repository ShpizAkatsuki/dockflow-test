import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeAppData, emptyData } from './normalize.ts';

const sample = () => ({
  categories: [
    { id: 'c1', name: 'כספים', icon: 'fa-wallet', subs: [{ id: 'sub-a', name: 'רכב' }],
      folders: [{ id: 'f1', name: 'חשבוניות', subId: 'sub-a' }, { id: 'f2', name: '2026', parentId: 'f1', subId: '' }, { id: 'bad', name: 'יתום', parentId: 'nope' }] },
    { id: 'c2', name: 'אחר' }
  ],
  documents: [
    { id: 'd1', title: 'א', categoryId: 'c1', folderId: 'f2', status: 'approved', expiryDate: '2026-12-01', tags: ['חשבונית', 'חשבונית '], fileKey: 'k1', fileName: 'a.pdf', versions: [{ version: 'v1.0', fileKey: 'k1' }] },
    { id: 'd2', title: 'ב', categoryId: 'c1', folderId: 'ghost', tags: ['ענן'], fileName: 'fake.pdf', size: '1.5 MB', versions: [{ version: 'v1.0' }] }
  ],
  tags: ['גלובלית']
});

test('נתונים לא תקינים -> מצב ריק', () => {
  assert.deepEqual(normalizeAppData(null), emptyData());
  assert.deepEqual(normalizeAppData({ categories: 5 }), emptyData());
});
test('סטטוס ותאריך תפוגה נמחקים מהמסמכים', () => {
  const d = normalizeAppData(sample()).documents[0] as unknown as Record<string, unknown>;
  assert.equal('status' in d, false);
  assert.equal('expiryDate' in d, false);
});
test('תיקיית משנה יורשת את תת-הקטגוריה של האב, ותיקיה יתומה עוברת לשורש', () => {
  const c = normalizeAppData(sample()).categories[0]!;
  assert.equal(c.folders.find((f) => f.id === 'f2')!.subId, 'sub-a');
  assert.equal(c.folders.find((f) => f.id === 'bad')!.parentId, '');
});
test('מסמך שמצביע על תיקיה שלא קיימת עובר לשורש, והמסמך בתיקיית משנה מקבל את תת-הקטגוריה', () => {
  const docs = normalizeAppData(sample()).documents;
  assert.equal(docs[1]!.folderId, '');
  assert.equal(docs[0]!.subId, 'sub-a');
});
test('שם קובץ וגרסאות מדומים (בלי קובץ אמיתי) מנוקים', () => {
  const d = normalizeAppData(sample()).documents[1]!;
  assert.equal(d.fileName, ''); assert.equal(d.size, ''); assert.deepEqual(d.versions, []);
});
test('תגיות: ספרייה לפי קטגוריה, בלי כפילויות; גלובליות ישנות נכנסות פעם אחת', () => {
  const data = normalizeAppData(sample());
  assert.deepEqual(data.categories[0]!.tags.sort(), ['גלובלית', 'ענן', 'חשבונית'].sort());
  assert.deepEqual(data.documents[0]!.tags, ['חשבונית']);
  const again = normalizeAppData(data); // הרצה שנייה לא משנה כלום
  assert.deepEqual(again, data);
});
test('אייקון לא תקין מוחלף באייקון ברירת מחדל', () => {
  const c = normalizeAppData({ categories: [{ id: 'x', name: 'x', icon: '"><script>' }], documents: [] }).categories[0]!;
  assert.equal(c.icon, 'fa-folder');
});

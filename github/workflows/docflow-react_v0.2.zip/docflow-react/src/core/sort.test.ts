import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { DocItem } from './types.ts';
import { moveWithin, reorderDocs, sortDocs, sortNamed, sortedCategories } from './sort.ts';
import type { Category } from './types.ts';

const doc = (id: string, title: string, date: string, order?: number): DocItem => ({
  id, title, categoryId: 'c', subId: '', folderId: '', tags: [], content: '', date, size: '', fileName: '', fileKey: '', fileType: 'other',
  versions: [], isFavorite: false, isDeleted: false, ...(order === undefined ? {} : { order })
});
const docs = [doc('doc-1', 'בטא', '2026-03-01'), doc('doc-2', 'אלפא', '2026-01-01'), doc('doc-3', 'גמא', '2026-02-01')];
const names = (l: DocItem[]): string => l.map((d) => d.title).join(',');

test('מיון לפי שם ולפי תאריך', () => {
  assert.equal(names(sortDocs(docs, 'name')), 'אלפא,בטא,גמא');
  assert.equal(names(sortDocs(docs, 'name-desc')), 'גמא,בטא,אלפא');
  assert.equal(names(sortDocs(docs, 'date-desc')), 'בטא,גמא,אלפא');
  assert.equal(names(sortDocs(docs, 'date-asc')), 'אלפא,גמא,בטא');
});
test('סדר ידני: מסמכים בלי סדר למעלה (החדשים קודם), ואז לפי מספר הסדר', () => {
  const l = [doc('doc-1', 'א', '2026-01-01', 1), doc('doc-2', 'ב', '2026-01-01', 0), doc('doc-3', 'ג', '2026-05-01')];
  assert.equal(names(sortDocs(l, 'manual')), 'ג,ב,א');
});
test('הזזה ידנית של מסמך', () => {
  const shown = sortDocs(docs, 'date-desc');
  const order = reorderDocs(shown, 'doc-3', 1)!;
  const after = sortDocs(shown.map((d) => ({ ...d, order: order.get(d.id)! })), 'manual');
  assert.equal(names(after), 'בטא,אלפא,גמא');
  assert.equal(reorderDocs(shown, 'doc-1', -1), null); // כבר ראשון
});
test('sortNamed ו-moveWithin', () => {
  const items = [{ id: 'x-1', name: 'ת' }, { id: 'x-2', name: 'א' }];
  assert.equal(sortNamed(items, 'name').map((i) => i.name).join(), 'א,ת');
  assert.equal(sortNamed(items, 'manual').map((i) => i.name).join(), 'ת,א');
  const all = ['a', 'b', 'c', 'd'];
  assert.deepEqual(moveWithin(all, (x) => x !== 'b', 'c', -1), ['c', 'b', 'a', 'd']); // שכנים בקבוצה: a,c,d
  assert.equal(moveWithin(all, () => true, 'a', -1), null);
});

test('קטגוריות עם כוכב ראשונות, והסדר ביניהן נשמר', () => {
  const c = (id: string, fav: boolean): Category => ({ id, name: id, description: '', icon: 'fa-folder', isFavorite: fav, subs: [], folders: [], tags: [] });
  assert.equal(sortedCategories([c('a', false), c('b', true), c('c', false), c('d', true)]).map((x) => x.id).join(), 'b,d,a,c');
});

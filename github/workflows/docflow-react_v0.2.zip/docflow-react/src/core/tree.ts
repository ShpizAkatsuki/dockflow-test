import type { Category, DocItem } from './types.ts';

export const zipSafe = (s: unknown): string =>
  // eslint-disable-next-line no-control-regex
  String(s ?? '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/^\.+/, '').trim().slice(0, 80) || 'ללא שם';

export const folderChildren = (cat: Category, parentId: string) =>
  cat.folders.filter((f) => (f.parentId || '') === (parentId || ''));

export function descendantFolderIds(cat: Category, folId: string): string[] {
  const out: string[] = []; const seen = new Set([folId]);
  const walk = (id: string): void => cat.folders.filter((f) => f.parentId === id).forEach((f) => {
    if (seen.has(f.id)) return; seen.add(f.id); out.push(f.id); walk(f.id);
  });
  walk(folId);
  return out;
}

export function folderChain(cat: Category, folId: string): string[] {
  const names: string[] = []; let cur = cat.folders.find((f) => f.id === folId); let g = 0;
  while (cur && g++ < 50) { names.unshift(cur.name); const pid: string = cur.parentId; cur = cat.folders.find((f) => f.id === pid); }
  return names;
}
export const folderPath = (cat: Category, folId: string): string => folderChain(cat, folId).join(' › ');

export function folderOptions(cat: Category, excludeIds: string[] = []): { id: string; label: string }[] {
  const out: { id: string; label: string }[] = [];
  const walk = (pid: string): void => folderChildren(cat, pid).forEach((f) => {
    if (excludeIds.includes(f.id)) return;
    out.push({ id: f.id, label: folderPath(cat, f.id) });
    walk(f.id);
  });
  walk('');
  return out;
}

/** נתיב התיקיות של מסמך: קטגוריה > תת-קטגוריה > תיקיות (שמות בטוחים לקבצים) */
export function docDirs(cat: Category | undefined, d: DocItem): string[] {
  if (!cat) return [];
  const sub = cat.subs.find((s) => s.id === d.subId);
  return [cat.name, sub?.name, ...folderChain(cat, d.folderId)].filter((x): x is string => !!x).map(zipSafe);
}

/** שם ייחודי בתוך תיקיה: name, name (2), name (3)... */
export function uniqueName(used: Set<string>, dirs: string[], fname: string): string {
  const dir = dirs.join('/') + '/';
  const dot = fname.lastIndexOf('.');
  const stem = dot > 0 ? fname.slice(0, dot) : fname;
  const ext = dot > 0 ? fname.slice(dot) : '';
  let name = fname; let n = 2;
  while (used.has((dir + name).toLowerCase())) name = `${stem} (${n++})${ext}`;
  used.add((dir + name).toLowerCase());
  return name;
}

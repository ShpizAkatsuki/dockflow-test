import { useMemo } from 'react';
import { useAppData } from './state/useAppData.ts';
import { dateMinus } from './core/ids.ts';
import { sortedCategories } from './core/sort.ts';

function Square({ label, value }: { label: string; value: number }) {
  return (
    <div className="aspect-square min-w-0 rounded-2xl border border-apple-border/50 bg-white p-1.5 text-center shadow-sm flex flex-col items-center justify-center dark:border-apple-darkBorder dark:bg-apple-darkCard">
      <span className="text-2xl font-bold leading-none">{value}</span>
      <span className="mt-1 text-[10px] leading-tight text-apple-gray sm:text-xs">{label}</span>
    </div>
  );
}

/** שלב 1: מעטפת בסיסית שמוכיחה שהליבה (מודל הנתונים) עובדת בתוך ריאקט. המסכים המלאים יועברו בשלבים הבאים. */
export default function App() {
  const { data } = useAppData();
  const stats = useMemo(() => {
    const live = data.documents.filter((d) => !d.isDeleted);
    const since = dateMinus(6);
    return {
      docs: live.length,
      cats: data.categories.length,
      favs: live.filter((d) => d.isFavorite).length,
      recent: live.filter((d) => d.date >= since).length
    };
  }, [data]);

  return (
    <div className="min-h-screen bg-apple-bg p-4 text-apple-dark dark:bg-apple-darkBg dark:text-gray-100">
      <header className="mx-auto mb-5 max-w-3xl">
        <h1 className="text-3xl font-bold tracking-tight">DocFlow</h1>
        <p className="text-sm text-apple-gray">גרסת ריאקט: שלב 1 (ליבה)</p>
      </header>
      <main className="mx-auto max-w-3xl space-y-6">
        <section className="grid max-w-md grid-cols-4 gap-2">
          <Square label="מסמכים" value={stats.docs} />
          <Square label="קטגוריות" value={stats.cats} />
          <Square label="מועדפים" value={stats.favs} />
          <Square label="נוספו לאחרונה" value={stats.recent} />
        </section>
        <section className="space-y-2">
          <h2 className="text-lg font-bold">קטגוריות</h2>
          {data.categories.length === 0 && <p className="text-sm text-apple-gray">אין קטגוריות עדיין.</p>}
          {sortedCategories(data.categories).map((c) => (
            <div key={c.id} className="flex items-center justify-between rounded-2xl border border-apple-border/50 bg-white p-4 shadow-sm dark:border-apple-darkBorder dark:bg-apple-darkCard">
              <span className="font-semibold">{c.isFavorite ? '★ ' : ''}{c.name}</span>
              <span className="text-xs text-apple-gray">{data.documents.filter((d) => d.categoryId === c.id && !d.isDeleted).length} מסמכים</span>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}

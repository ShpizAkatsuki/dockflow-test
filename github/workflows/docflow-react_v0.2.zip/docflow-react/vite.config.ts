import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' כדי שהאתר יעבוד גם בכתובת של GitHub Pages שמכילה שם פרויקט
export default defineConfig({ base: './', plugins: [react()] });

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: { sans: ['Heebo', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'] },
      colors: { apple: { bg: '#F5F5F7', darkBg: '#0D0D0E', darkCard: '#1C1C1E', darkBorder: '#2C2C2E', dark: '#1D1D1F', gray: '#6E6E73', lightGray: '#F2F2F7', border: '#D2D2D7', blue: '#0071E3', blueHover: '#0077ED' } }
    }
  },
  plugins: []
};
